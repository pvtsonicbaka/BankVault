import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Random;
import java.util.Scanner;

public class TransactionManager {
    AccountManagement am=new AccountManagement();
    Loan loan=new Loan();
    Scanner sc = new Scanner(System.in);
    int pin;
    int to_cid;
    int from_cid;
    String DateOfTransaction;
    double balance;
    double amount;
    String acc_no;
    Connection con;
    PreparedStatement ps;

    TransactionManager(){   
        Connector connector = new Connector();
        con =  connector.getCon();
    }

    void withDraw()throws Exception{
        am.getAccID();
        System.out.println("Enter Account Number");
        String acc=sc.next();
        if(am.checkAccount(acc)){
            if(am.hsacc.containsKey(acc)){
                pin=am.checkPIN();
                if(am.hsacc.get(acc)==pin){
                    System.out.println("Set Amount to Withdraw");
                    amount=am.checkBalance();
                    balance=checkForWithdraw(acc);
                    if(balance>=amount){
                        double newbalance = balance-amount;
                        String sql1 = "update account set Balance=? where accno=?";
                        ps=con.prepareStatement(sql1);
                        ps.setDouble(1, newbalance);
                        ps.setString(2, acc);
                        int rs = ps.executeUpdate();
                        if (rs>0) {
                            System.out.println("Rs:- "+amount +"/-  Is WithDraw Succesfully");
                            LocalDate currentDate = LocalDate.now();
                            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
                            String formattedDate = currentDate.format(formatter);                        
                        makePassBook(acc, newbalance,formattedDate , "Withdraw",amount);
                        } else {
                            System.out.println("Payment failed");
                        }
                    }else{
                        System.out.println("Insufficient Balance to Withdraw");
                    }
                }else{
                    System.out.println("Invalid PIN");
                }
            }else{
                System.out.println("Account Number Not Found");
            }
        }else{
            System.out.println("Invalid Account Number");
        }

    }

    // method for deposite
    void deposite()throws Exception{
        am.getAccID();
        System.out.println("Enter Account Number");
        String acc=sc.next();
        if(am.checkAccount(acc)){
            //gs46473224
            if(am.hsacc.containsKey(acc)){
                pin=am.checkPIN();
                if(am.hsacc.get(acc)==pin){
                    System.out.println("Set Amount to Deposite");
                    amount=am.checkBalance();
                    balance=checkForWithdraw(acc);
                        double newbalance = balance+amount;
                        String sql1 = "update account set Balance=? where accno=?";
                        ps=con.prepareStatement(sql1);
                        ps.setDouble(1, newbalance);
                        ps.setString(2, acc);
                        int rs = ps.executeUpdate();
                        if (rs>0) {
                            System.out.println("Rs:- "+amount +"/-  Is Deposited Succesfully");
                            LocalDate currentDate = LocalDate.now();
                            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
                            String formattedDate = currentDate.format(formatter);                        
                        makePassBook(acc, newbalance,formattedDate , "Deposite",amount);
                        } else {
                            System.out.println("Payment failed");
                        }
                }else{
                    System.out.println("Invalid PIN");
                }
            }else{
                System.out.println("Account Number Not Found");
            }
        }else{
            System.out.println("Invalid Account Number");
        } 
    }
    
    public void accountTOaccount()throws Exception{
        am.getAccID();
        System.out.println("Enter Account Number");
        String fromacc=sc.next();
        if(am.checkAccount(fromacc)){
            if(am.hsacc.containsKey(fromacc)){
                pin=am.checkPIN();
                if(am.hsacc.get(fromacc)==pin){
                    System.out.println("Enter Receiver Account Number");
                    String toacc=sc.next();
                    if(am.checkAccount(toacc)){
                        if(!toacc.equals(fromacc)){
                        if(am.hsacc.containsKey(toacc)){
                    System.out.println("Set Amount to Transfer");
                    amount=am.checkBalance();
                    double frombalance=checkForWithdraw(fromacc);
                    double tobalance=checkForWithdraw(toacc);
                    if(frombalance>=amount){
                        double newbalance = frombalance-amount;
                        String sql1 = "update account set Balance=? where accno=?";
                        ps=con.prepareStatement(sql1);
                        ps.setDouble(1, newbalance);
                        ps.setString(2, fromacc);
                        int rs = ps.executeUpdate();
                        if (rs>0) {
                            double toupdatebalance=tobalance+amount;
                           String sql2="update account set Balance=? where accno=?";
                           ps=con.prepareStatement(sql2);
                           ps.setDouble(1, toupdatebalance);
                           ps.setString(2, toacc);
                           int rs2=ps.executeUpdate();
                           if(rs2>0){
                            LocalDate currentDate = LocalDate.now();
                            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
                            String formattedDate = currentDate.format(formatter);                        
                        makePassBookAtoA(fromacc, newbalance,toupdatebalance,formattedDate,"Transfer","Received",amount,toacc);
                        String sql="Insert into transaction Values(?,?,?,?,?)";
                        ps=con.prepareStatement(sql);
                        ps.setString(1, generatetransactionId());
                        ps.setString(2, fromacc);
                        ps.setString(3, toacc);
                        ps.setDouble(4, amount);
                        ps.setString(5, formattedDate);
                        int rs3=ps.executeUpdate();
                        if(rs3>0){
                            System.out.println(amount+" Rs/- Transfrom From "+fromacc+" TO "+toacc+" Succesfully");
                            loan.setData(fromacc);
                        }
                           }
                        } else {
                            System.out.println("Payment failed");
                        }
                    }else{
                        System.out.println("Insufficient Balance to Transfer");
                    }
                }else{
                    System.out.println("Reciever Account Number Not Found");
                }
            }else{
                System.out.println("Receiver and Sender Account can not be same");
            }
                }else{
                    System.out.println("Invalid Reciever Account Number");
                }
                }else{
                    System.out.println("Invalid PIN");
                }
            }else{
                System.out.println("Account Number Not Found");
            }
        }else{
            System.out.println("Invalid Account Number");
        }
        
    }
    static void makePassBook(String acc_no,double balance,String Date,String mode,double amount){
        File f = new File("PassBook_For_"+acc_no+".txt");
        try {
            FileWriter fw = new FileWriter(f,true);
            fw.write(amount+"_"+mode+"_BY_"+"Self_ON_"+Date+"_Balance: "+balance+"\n");
            fw.close();

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    static void makePassBookAtoA(String fromacc_no,double frombalance,double tobalance,String Date,String mode1,String mode2,double amount,String toacc_no){
        File f1 = new File("PassBook_For_"+fromacc_no+".txt");
        File f2 = new File("PassBook_For_"+toacc_no+".txt");

        try {
            FileWriter fw1 = new FileWriter(f1,true);
            FileWriter fw2 = new FileWriter(f2,true);

            fw1.write(amount+"_"+mode1+"_TO_"+toacc_no+"_ON_"+Date+"_Balance: "+frombalance+"\n");
            fw2.write(amount+"_"+mode2+"_FROM_"+toacc_no+"_ON_"+Date+"_Balance: "+tobalance+"\n");
            fw1.close();
            fw2.close();

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    public double  checkForWithdraw(String accno) throws Exception{
        String sql="select * from account where accno=?";
        ps=con.prepareStatement(sql);
        ps.setString(1, accno);
        ResultSet rs=ps.executeQuery();
        while(rs.next()){
            balance=rs.getDouble("Balance");
        }
        return balance;
    }
    public static String generatetransactionId() {
        Random random = new Random();
        StringBuilder accountId = new StringBuilder();

        for (int i = 0; i < 10; i++) {
            accountId.append(random.nextInt(10));
        }

        return accountId.toString();
    }
    public void printPassbook(){
        try{
        am.getAccID();
        System.out.println("Enter Account Number");
        String acc=sc.next();
        if(am.checkAccount(acc)){
            if(am.hsacc.containsKey(acc)){
                pin=am.checkPIN();
                if(am.hsacc.get(acc)==pin){
                    FileReader fr=new FileReader("PassBook_For_"+acc+".txt");
                    int i=fr.read();
                    while(i!=-1){
                        System.out.print((char)i);
                        i=fr.read();
                    }
                    System.out.println();
                    fr.close();
                }else{
                    System.out.println("Invalid PIN");
                }
            }else{
                System.out.println("Account Number Not Found");
            }
        }else{
            System.out.println("Invalid Account Number");
        }
    }catch(Exception e){
        System.out.println("Transaction is not been done yet");
    }
    }
}