import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Scanner;


public class DataStructureImplementation {
    class Node{
        Loan l;
        Node next;
        Node(Loan l){
            this.l=l;
        }
    }
    Node head=null;
    Connection con1;
    String stack []=new String[1000];
    int top = -1;

    public DataStructureImplementation() {
        Connector con = new Connector();
        con1 = con.getCon();
    }
    public DataStructureImplementation(String acc) throws Exception{
        try{
        Scanner sc=new Scanner(System.in);
            FileReader fr=new FileReader("PassBook_For_"+acc+".txt");
            BufferedReader br=new BufferedReader(fr);
            String line=br.readLine();
            String sign;
            while(line!=null){
            String s[]=line.split("_");
            String amount=s[0];
            String method=s[1];
            if(s[1].equals("Received") || s[1].equals("Deposite")){
                sign="+";
            }else{
                sign="-";
            }
            String acno=s[3];
            String date=s[5];
            push("Date:-"+date+"\nAccount Number:-"+acno+"\t"+sign+amount);
            line=br.readLine();
            }
            boolean b=true;
            while(b){
            System.out.println("1-View Transaction History");
                System.out.println("2-Rectrive and Delete Latest Transaction");
                System.out.println("3-Exit");
                System.out.print("Enter Your Choice:-");
                int ch=sc.nextInt();
                switch (ch) {
                    
                    case 1:display();
                        break;
                        case 2:
        System.out.println("---------------------------------------------------");
                        System.out.println(pop());
        System.out.println("---------------------------------------------------");

                        break;
                        case 3:b=false;break;
                    default:
                        System.out.println("Invalid Input");
                }
            }
                    br.close();
                }catch(FileNotFoundException e){
                    System.out.println("No Transaction Done Yet");
                }
    }

    void push(String data){
        if (top==stack.length-1) {
            System.out.println("You have Reached to your Limit");
            return;
        }
        top++;
        stack[top] = data;
    }
    public String pop(){
        if (top == -1) {
            System.out.println("No Record Found");
        }
        return stack[top--];
    }
    public void display(){
        System.out.println("---------------------------------------------------");
        for(int i=top;i>=0;i--){
            System.out.println(stack[i]);
            System.out.println();
        }
        System.out.println("---------------------------------------------------");

    }
    public void setList() throws Exception{
        String sql="select * from Loan where status='Eligible'";
        PreparedStatement ps=con1.prepareStatement(sql);
        ResultSet rs=ps.executeQuery();
        while(rs.next()){
            int id=rs.getInt(1);
            String name=rs.getString(2);
            int score=rs.getInt(3);
            String status=rs.getString(4);
            Loan myloan=new Loan(id,name,score,status);
            insert(myloan);
        }
    }
    public void insert(Loan loan) {
    Node n1 = new Node(loan);
    if (head == null || head.l.credit < n1.l.credit) {
        n1.next = head;
        head = n1;
    } else {
        Node current = head;
        while (current.next != null && current.next.l.credit >= n1.l.credit) {
            current = current.next;
        }
        n1.next = current.next;
        current.next = n1;
    }
}
void generateList() throws Exception{
    BufferedWriter bw=new BufferedWriter(new FileWriter("Top Customer for Loan Approval.txt"));
    Node current = head;
    if(current==null){
        System.out.println("No customer Eligible for Loan");
    }else{
    while (current != null) {
        bw.write("Customer ID:- "+current.l.id+"\n");
        bw.write("Customer Name:- "+current.l.name+"\n");
        bw.write("Credit Score:- "+current.l.credit+"\t    \t"+"Status:- "+current.l.status+"\n");
        bw.write("--------------------------------------------------------------"+"\n");
        bw.newLine();
        current = current.next;
    }
    bw.close();
}
}
}