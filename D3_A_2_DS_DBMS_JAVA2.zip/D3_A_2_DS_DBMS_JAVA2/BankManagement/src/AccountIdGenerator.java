import java.util.Random;

public class AccountIdGenerator {

    public static String generateNumericAccountId() {
        Random random = new Random();
        StringBuilder accountId = new StringBuilder();

        for (int i = 0; i < 12; i++) {
            accountId.append(random.nextInt(10));
        }

        return accountId.toString();
    }

    public static void main(String[] args) {
        String accountId = generateNumericAccountId();
        System.out.println(accountId);
    }
}
