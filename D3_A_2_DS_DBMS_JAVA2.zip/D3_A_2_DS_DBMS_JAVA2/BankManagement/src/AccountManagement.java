import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.HashMap;
import java.util.Random;
import java.util.Scanner;
public class AccountManagement {
    Connection con;
    PreparedStatement ps;
    HashMap<String, Double> acc_balance = new HashMap<>();
    HashMap<String,Integer>hsacc=new HashMap<>();
    CustomerManagement cm=new CustomerManagement();
    Scanner sc=new Scanner(System.in);
    String accno;
    int c_id;
    double balance;
    String type ;
    int pin;
    String  Date;

    public AccountManagement() {
        Connector connector = new Connector();
        this.con = connector.getCon();
    }

    void addAccount(){
        try{
        cm.getID();
        System.out.println("Enter ID Number");
        int cid=sc.nextInt();
        if(CustomerManagement.hscid.contains(cid)){
            boolean b=true;
            while(b){
                System.out.println("1-Saving \t 2-Current");
                int ch=sc.nextInt();
                switch(ch){
                    case 1:type="Saving";b=false;break;
                    case 2:type="Current";b=false;break;
                    default:System.out.println("Invalid choice");
                }
            }
            System.out.println("SET Initial Balance");
            balance=checkBalance();
            pin=checkPIN();
            String sql="INSERT into account VALUES (?,?,?,?,?)";
            ps=con.prepareStatement(sql);
            ps.setString(1, generateNumericAccountId());
            ps.setInt(2, cid);
            ps.setDouble(3, balance);
            ps.setString(4, type);
            ps.setInt(5, pin);
            int rs=ps.executeUpdate();
            if(rs>0){
                System.out.println("Account Added Succesfully");
            }
            
        }else{
            System.out.println("ID Not Found");
        }
    }catch(Exception e){
        System.out.println("Invalid Input");
    }
        
    }
    void delAccount(){
        try{
        getAccID();
        System.out.println("Enter Account Number");
        String acc=sc.next();
        if(checkAccount(acc)){
            if(hsacc.containsKey(acc)){
                pin=checkPIN();
                if(hsacc.get(acc)==pin){
                    String sql="Delete from account where accno=? AND PIN=?";
                    ps=con.prepareStatement(sql);
                    ps.setString(1, acc);
                    ps.setInt(2, pin);
                    int rs=ps.executeUpdate();
                    if(rs>0){
                        System.out.println("Account Deleted Succesfully");
                    }
                }else{
                    System.out.println("Invalid PIN");
                }
            }else{
                System.out.println("Account Number Not Found");
            }
        }else{
            System.out.println("Invalid Account Number");
        }
    }catch(Exception e){
        System.out.println("Invalid Input");
    }
        
    }
    void updatAccountPin() throws Exception{
        getAccID();
        System.out.println("Enter Account Number");
        String acc=sc.next();
        if(checkAccount(acc)){
            if(hsacc.containsKey(acc)){
                pin=checkPIN();
                if(hsacc.get(acc)==pin){
                    System.out.println("SET New PIN");
                    int newpin=checkPIN();
                    String sql="update account set PIN=? where accno=? AND PIN=?";
                    ps=con.prepareStatement(sql);
                    ps.setInt(1, newpin);
                    ps.setString(2, acc);
                    ps.setInt(3, pin);
                    int rs=ps.executeUpdate();
                    if(rs>0){
                        System.out.println("PIN Updated Succesfully");
                    }
                }else{
                    System.out.println("Invalid PIN");
                }
            }else{
                System.out.println("Account Number Not Found");
            }
        }else{
            System.out.println("Invalid Account Number");
        }

    }
    
    public static String generateNumericAccountId() {
        Random random = new Random();
        StringBuilder accountId = new StringBuilder();

        for (int i = 0; i < 12; i++) {
            accountId.append(random.nextInt(10));
        }

        return accountId.toString();
    }

    public double  checkBalance(){
        try{
        boolean b=true;
        String balance="";
        while(b){
        System.out.println("Enter Amount");
        balance=sc.next();
            for(int i=0;i<balance.length();i++){
                if(Character.isAlphabetic(balance.charAt(i))){
                    b=true;
                   break;
                }else{
                    b=false;
                    continue;
                }
            }
        }
        return Double.parseDouble(balance);
    }catch(Exception e){
        System.out.println("Invalid Input");
        return 0;
    }
    }

    public int checkPIN(){
        boolean b=true;
    String pin="";
    while(b){
    System.out.println("Enter PIN");
    pin=sc.next();
    if(pin.length()==4){
        int count1=0;
        for(int i=0;i<pin.length();i++){
            if(Character.isDigit((int)pin.charAt(i))){
                count1++;
            }else{
                break;
            }
        }
        if(count1!=4){
            System.out.println("Invalid PIN");
        }else{
            b=false;
            
        }
    }else{
        System.out.println("PIN contains only 4 digits.");
    }
}
    return Integer.parseInt(pin);
    }
public boolean  checkAccount(String accno){
    boolean result=true;
        for(int i=0;i<accno.length();i++){
            if(Character.isAlphabetic(accno.charAt(i)) && accno.charAt(i)!=' '){
                result=false;
                break;
            }else{
                result=true;
                continue;
            }
        }
        return result;
}
    public void getAccID() throws Exception{
        hsacc.clear();
        String sql="Select * from account";
        ps=con.prepareStatement(sql);
        ResultSet rs=ps.executeQuery();
        while(rs.next()){
            hsacc.put(rs.getString("accno"), rs.getInt("PIN"));
        }
    }
    public void viewBalance() throws Exception{
        setBalance();
        getAccID();
        System.out.println("Enter Account Number");
        accno=sc.next();
        if(checkAccount(accno)){
            pin=checkPIN();
            if(hsacc.get(accno)==pin){
            if(acc_balance.containsKey(accno)){
                System.out.println("Account Number:-"+accno);
                System.out.println("Balance:-"+acc_balance.get(accno));
            }else{
                System.out.println("Account Number Not Found");
            }
        }else{
            System.out.println("Incorrect PIN");
        }
        
        }else{
            System.out.println("Invalid Account Number");
        }
    }
    public void setBalance() throws Exception{
        acc_balance.clear();
        String sql="select * from account";
        ps=con.prepareStatement(sql);
        ResultSet rs=ps.executeQuery();
        while(rs.next()){
            acc_balance.put(rs.getString("accno"), rs.getDouble("Balance"));
        }
    }
}
