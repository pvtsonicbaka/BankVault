import java.sql.Connection;
import java.sql.DriverManager;

public class Connector {
    String url = "jdbc:mysql://localhost:3306/bank";
    String user = "root";
    String password = "";
    static Connection con;
    public  Connector(){
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            con = DriverManager.getConnection(url, user, password);
            // System.out.println("Connected to Database Successfully");
            
        } catch (Exception e) {

            System.out.println("");
        }
        
    }
    public static Connection getCon() {
        return con;
    }

    
}
