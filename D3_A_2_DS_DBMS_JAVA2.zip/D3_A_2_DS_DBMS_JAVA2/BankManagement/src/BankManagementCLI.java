
import java.sql.Connection;
import java.util.Scanner;

public class BankManagementCLI {

    Connection con;

    public static void main(String[] args) throws Exception {
        CustomerManagement cm=new CustomerManagement();
        AccountManagement am=new AccountManagement();
        TransactionManager tm=new TransactionManager();
        DataStructureImplementation dsa=new DataStructureImplementation();
        Loan loan=new Loan();
        Scanner sc = new Scanner(System.in);
        boolean repeate=true;
        while (repeate) {
            System.out.println("--------------------------------------------");
            System.out.println("Enter 1 : Register a Customer");
            System.out.println("Enter 2 : to update Customer Information");
            System.out.println("Enter 3 : to Delete Customer");
            System.out.println("Enter 4 : to add Account");
            System.out.println("Enter 5 : to delete Account");
            System.out.println("Enter 6 : to update PIN ");
            System.out.println("Enter 7 : to Withdraw ");
            System.out.println("Enter 8 : to Deposite ");
            System.out.println("Enter 9 : to Account to account transfer ");
            System.out.println("Enter 10 : to see balance  ");
            System.out.println("Enter 11 : Rectrive Passbook");
            System.out.println("Enter 12 : Transaction History");
            System.out.println("Enter 13 : Check Credit Score And Loan Status");
            System.out.println("Enter 14 : Generate List of Top Loan Approval ");
            System.out.println("Enter 15 : to Exit.. ");
            System.out.println("--------------------------------------------");
            System.out.print("Enter your Choice:-");
          try{
            int n = sc.nextInt();
            switch (n) {
                

                case 1:
                    cm.addCustomer();
                    
                    break;

                case 2:
                    cm.updateCustomer();
                    break;

                case 3:
                    cm.deleteCustomer();
                    break;

                case 4:
                    am.addAccount();
                    break;

                case 5:
                    am.delAccount();
                    break;
                case 6:
                    am.updatAccountPin();
                    break;

                case 7:

                    tm.withDraw();
                    break;

                case 8:
                    tm.deposite();
                    break;

                case 9:
                    tm.accountTOaccount();
                    break;

                case 10:
                    am.viewBalance();
                    break;

                case 11:
                    tm.printPassbook();
                    break;
                case 12://ds
                    System.out.println("Enter Account Number");
                    String accno=sc.next();
                    am.getAccID();
                    if(am.checkAccount(accno)){
            if(am.hsacc.containsKey(accno)){
                DataStructureImplementation dsi=new DataStructureImplementation(accno);
            }else{
                System.out.println("Account Number not Found");
            }
                    }else{
                        System.out.println("Invalid Account Number");
                    }
                    break;
                    
                    case 13:loan.getStatus();
                    break;
                    
                    case 14:
                    dsa.setList();
                    dsa.generateList();
                    break;
                    
                case 15:repeate=false;
                    System.out.println("THANK_YOU");
                    break;
                default:System.out.println("Invalid Choice");
                    break;
            }
          }catch(Exception e){
            repeate=false;
            System.out.println(e);
            System.out.println("Invalid Input");
          }
        }
    }
}
