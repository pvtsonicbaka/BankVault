import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashSet;
import java.util.Scanner;

public class CustomerManagement {
    Connection con ;
    PreparedStatement ps ;
    static HashSet<Integer> hscid=new HashSet<>();
    Scanner sc  = new Scanner(System.in);
    String name;
    String pass;
    String phone;
    String address;
    String aadhar;
    String Gender ;
    String age;

    public CustomerManagement() {
        Connector connector = new Connector();
        this.con =connector.getCon();
        if(con==null){
            try {
                throw new SQLException("Connected not succesfull");
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    } 

    void addCustomer() throws Exception{
        System.out.println("Enter Name of Customer");
        name=sc.next();
        if(checkname(name)){
            System.out.println("Enter Password");
            pass=sc.next();
            System.out.println("Enter Address");
            address=sc.next();
            phone=checkNumber();
            boolean b=true;
            while(b){
                System.out.println("1-Male \t 2-Female \t 3-Other");
                int ch=sc.nextInt();
                switch(ch){
                    case 1:Gender="Male";b=false;break;
                    case 2:Gender="Female";b=false;break;
                    case 3:Gender="Other";b=false;break;
                    default:System.out.println("Invalid choice");
                }
            }
            aadhar=checkAadhar();
            boolean b2=true;
            while(b2){
            System.out.println("Enter Age");
            age=sc.next();
            for(int i=0;i<age.length();i++){
                if(Character.isDigit(age.charAt(i))){
                    b2=false;
                    continue;
                }else{
                    break;
                }
            }
            }
            String sql  = String.format("insert into customer (cname,cpass,cadd,cphone,gender,aadhar,age) values (?,?,?,?,?,?,?)");
             ps = con.prepareStatement(sql);
             ps.setString(1, name);
             ps.setString(2, pass);

             ps.setString(3, address);
             ps.setString(4, phone);
             ps.setString(5, Gender);
             ps.setString(6, aadhar);
             ps.setString(7, age);
             int rs = ps.executeUpdate();
             if(rs>0){
                System.out.println("Customer Added Succesfully");
                String sql1="Select cid from customer where aadhar='"+aadhar+"'";
                ps=con.prepareStatement(sql1);
                ResultSet rset=ps.executeQuery();
                while(rset.next()){
                    String sql2="Call insertData(?,?)";
                    CallableStatement cst=con.prepareCall(sql2);
                    cst.setInt(1, rset.getInt(1));
                    cst.setString(2, name);
                    cst.execute();
                }
             }
             else{
                System.out.println("Customer Not Added");
             }

            
        }else{
            System.out.println("Invalid Name");
        }
    }

    void deleteCustomer() throws Exception{
        System.out.println("Enter Name of Customer");
        name=sc.next();
        if(checkname(name)){
        System.out.println("Enter Password");
        pass=sc.next();
        System.out.println("Enter ID Number");
        int cid=sc.nextInt();
        String sql = String.format("Delete from customer where cname = ? And cpass =? AND cid=?");
            ps = con.prepareStatement(sql);
            ps.setString(1, name);
            ps.setString(2, pass);
            ps.setInt(3, cid);
            int rs = ps.executeUpdate();
            if(rs>0){
                String sql2="Delete from account where cid='"+cid+"'";
                ps=con.prepareStatement(sql2);
                ps.execute();
            System.out.println("Customer Deleted Succesfully");
            }
            else{
            System.out.println("Customer Not Found");
            }
        }else{
            System.out.println("Invalid Name");
        }

    }
    public void updateCustomer() throws Exception{
        getID();
        System.out.println("Enter ID Number");
        int cid=sc.nextInt();
        if(hscid.contains(cid)){
            System.out.println("Enter Name");
            name=sc.next();
            if(checkname(name)){
                System.out.println("Enter Password");
                pass=sc.next();
                System.out.println("Enter Address");
                address=sc.next();
                phone=checkNumber();
            boolean b=true;
            while(b){
                System.out.println("1-Male \t 2-Female \t 3-Other");
                int ch=sc.nextInt();
                switch(ch){
                    case 1:Gender="Male";b=false;break;
                    case 2:Gender="Female";b=false;break;
                    case 3:Gender="Other";b=false;break;
                    default:System.out.println("Invalid choice");
                }
            }
            aadhar=checkAadhar();
            boolean b2=true;
            while(b2){
            System.out.println("Enter Age");
            age=sc.next();
            for(int i=0;i<age.length();i++){
                if(Character.isDigit(age.charAt(i))){
                    b2=false;
                    continue;
                }else{
                    break;
                }
            }
            }
            String sql="update customer set cname=?,cpass=?,cadd=?,cphone=?,gender=?,aadhar=?,age=? where cid=?";
            ps=con.prepareStatement(sql);
            ps.setString(1,name);
            ps.setString(2, pass);
            ps.setString(3, address);
            ps.setString(4, phone);
            ps.setString(5, Gender);
            ps.setString(6, aadhar);
            ps.setString(7, age);
            ps.setInt(8, cid);
            int rs=ps.executeUpdate();
            if(rs>0){
                System.out.println("Customer Details Updated Succesfully");
            }
            }else{
                System.out.println("Invalid Name");
            }
        }else{
            System.out.println("ID Not Found");
        }
    }
    public boolean checkname(String name){
        boolean result=true;
        for(int i=0;i<name.length();i++){
            if(Character.isAlphabetic(name.charAt(i)) && name.charAt(i)!=' '){
                continue;
            }else{
                result=false;
                break;
            }
        }
        return result;
    }
    public String checkNumber() throws Exception{
        boolean b=true;
        String newmo="";
        while(b){
        System.out.println("Enter Mobile Number.");
        newmo=sc.next();
        if(newmo.length()==10){
            int count1=0;
            for(int i=0;i<newmo.length();i++){
                if(Character.isDigit((int)newmo.charAt(i))){
                    count1++;
                }else{
                    break;
                }
            }
            if(count1!=10){
                System.out.println("Invalid Mobile Number.");
            }else{
                b=false;
                
            }
        }else{
            System.out.println("Mobile Number contains only 10 digits.");
        }
    }
        return newmo;
}
public String checkAadhar() throws Exception{
    boolean b=true;
    String newa="";
    while(b){
    System.out.println("Enter Aadhaar Card Number.");
    newa=sc.next();
    if(newa.length()==12){
        int count1=0;
        for(int i=0;i<newa.length();i++){
            if(Character.isDigit((int)newa.charAt(i))){
                count1++;
            }else{
                break;
            }
        }
        if(count1!=12){
            System.out.println("Invalid Aadhaar Card Number.");
        }else{
            b=false;
            
        }
    }else{
        System.out.println("Aadhaar Card Number contains only 12 digits.");
    }
}
    return newa;
}
public void getID() throws Exception{
    hscid.clear();
    String sql="Select * from customer";
    ps=con.prepareStatement(sql);
    ResultSet rs=ps.executeQuery();
    while(rs.next()){
        hscid.add(rs.getInt("cid"));
    }
}

}
