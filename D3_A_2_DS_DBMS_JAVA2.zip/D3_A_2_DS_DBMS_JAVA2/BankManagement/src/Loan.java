import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;
class Loan {
    Connection con;
    int id;
    int count;
    String name;
    int credit;
    double updateBalance;
    String status;

    public Loan() {
        AccountManagement amt=new AccountManagement();
        Connector connector = new Connector();
        this.con = connector.getCon();
        
    }
    
    public Loan(int id, String name, int credit, String status) {
        this.id = id;
        this.name = name;
        this.credit = credit;
        this.status = status;
    }

    void setData(String accno) throws SQLException, Exception{
        String sql="Call setData(?,?,?)";
        CallableStatement cst=con.prepareCall(sql);
        cst.setString(1, accno);
        cst.execute();
        this.id=cst.getInt(2);
        this.name=cst.getString(3);
        String sql2="Call getCount(?,?)";
        CallableStatement cst2=con.prepareCall(sql2);
        cst2.setInt(1, id);
        cst2.execute();
        this.count=cst2.getInt(2);
        String sql3="Call getBalance(?,?)";
        CallableStatement cst3=con.prepareCall(sql3);
        cst3.setInt(1, id);
        cst3.execute();
        updateBalance=cst3.getDouble(2);
        if(count<=1){
            credit=0;
            status="Not Eligible";
            insertData();
        }else{
            if(count>=10){
                credit=5;
            }else if(count>=5){
                if(updateBalance>=5000){
                    credit=4;
                }else{
                    credit=3;
                }
            }else{
                if(updateBalance>=5000){
                    credit=2;
                }else{
                    credit=1;
                }
            }
            if(credit>=3){
                status="Eligible";
            }else{
                status="Not Eligible";
            }
            updateData();
        }
    }
    void insertData() throws Exception{
        String sql="insert into loan values (?,?,?,?)";
        PreparedStatement pst=con.prepareStatement(sql);
        pst.setInt(1, this.id);
        pst.setString(2, this.name);
        pst.setInt(3, credit);
        pst.setString(4, status);
        int r=pst.executeUpdate();
        if(r>0){
            System.out.println("Sucess");
        }
    }
    void updateData()throws Exception{
        String sql="Update loan set credit_score=?,status=? where cid=?";
        PreparedStatement pst=con.prepareStatement(sql);
        pst.setInt(1, this.credit);
        pst.setString(2, this.status);
        pst.setInt(3, this.id);
        pst.execute();
    }
    void getStatus() throws Exception{
            boolean b=true;
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter Customer ID:-");
        int checkid=sc.nextInt();
        String Sql="Select * from loan where cid='"+checkid+"'";
        PreparedStatement pst=con.prepareStatement(Sql);
        ResultSet rs=pst.executeQuery();

        while(rs.next()){
            b=false;
            System.out.println("Credit Score:- "+rs.getInt(3));
            System.out.println("Status:- "+rs.getString(4));
        }
        if(b==true){
            System.out.println("Record Not Found");
        }
    }
}
