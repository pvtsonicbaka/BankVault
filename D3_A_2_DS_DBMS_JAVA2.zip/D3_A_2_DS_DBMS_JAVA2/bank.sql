-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 22, 2024 at 02:41 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.1.25

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `bank`
--

DELIMITER $$
--
-- Procedures
--
CREATE DEFINER=`root`@`localhost` PROCEDURE `getBalance` (IN `myid` INT, OUT `mybalance` DOUBLE)   Select SUM(Balance) into mybalance from account WHERE cid=myid GROUP By cid$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getCid` (IN `mypass` VARCHAR(50), IN `myphone` VARCHAR(50), OUT `myid` INT)   select cid into myid from customer where cpass=mypass and cphone=myphone$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getCount` (IN `acc` BIGINT, OUT `mycount` INT)   SELECT COUNT(*) into mycount from transaction inner join account on transaction.from_accNo=account.accno where account.cid=acc$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `setData` (IN `acc` BIGINT, OUT `myid` INT, OUT `myname` VARCHAR(50))   Select customer.cid,customer.cname into myid,myname from customer inner join account on customer.cid=account.cid where account.accno=acc$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `account`
--

CREATE TABLE `account` (
  `accno` bigint(11) NOT NULL,
  `cid` int(11) NOT NULL,
  `Balance` double NOT NULL,
  `Type` varchar(10) NOT NULL,
  `PIN` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `account`
--

INSERT INTO `account` (`accno`, `cid`, `Balance`, `Type`, `PIN`) VALUES
(352283830324, 42, 41899.02, 'Current', 1234);

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `mobile_no` bigint(20) NOT NULL,
  `password` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `name`, `mobile_no`, `password`) VALUES
(1, 'ajay shah', 9978888185, 'aju1');

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

CREATE TABLE `customer` (
  `cid` int(11) NOT NULL,
  `cname` varchar(30) NOT NULL,
  `cpass` varchar(8) NOT NULL,
  `cadd` varchar(100) NOT NULL,
  `cphone` varchar(10) NOT NULL,
  `gender` varchar(10) NOT NULL,
  `aadhar` varchar(12) NOT NULL,
  `age` int(3) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `customer`
--

INSERT INTO `customer` (`cid`, `cname`, `cpass`, `cadd`, `cphone`, `gender`, `aadhar`, `age`) VALUES
(42, 'keval joshi', '22012006', 'thane-mumbai', '9978888636', 'Male', '333344447878', 25);

--
-- Triggers `customer`
--
DELIMITER $$
CREATE TRIGGER `setCustomer` AFTER INSERT ON `customer` FOR EACH ROW Insert into registration VALUES(new.cid,new.cname,CURRENT_DATE,CURRENT_TIME)
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `updateCustomer` AFTER UPDATE ON `customer` FOR EACH ROW update registration set name=new.cname where name=old.cname
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `updateLoan` AFTER UPDATE ON `customer` FOR EACH ROW update loan set cname=new.cname where cname=old.cname
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `loan`
--

CREATE TABLE `loan` (
  `cid` int(11) NOT NULL,
  `cname` varchar(50) NOT NULL,
  `credit_score` int(11) NOT NULL,
  `status` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `loan`
--

INSERT INTO `loan` (`cid`, `cname`, `credit_score`, `status`) VALUES
(42, 'keval joshi', 0, 'Not Eligible');

-- --------------------------------------------------------

--
-- Table structure for table `registration`
--

CREATE TABLE `registration` (
  `cid` int(10) NOT NULL,
  `name` varchar(50) NOT NULL,
  `Date` date NOT NULL,
  `Time` time NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `registration`
--

INSERT INTO `registration` (`cid`, `name`, `Date`, `Time`) VALUES
(40, 'anant ambani', '2024-08-22', '14:16:24'),
(41, 'jaydeep patel', '2024-08-22', '14:33:40'),
(42, 'keval joshi', '2024-08-22', '18:05:42');

-- --------------------------------------------------------

--
-- Table structure for table `transaction`
--

CREATE TABLE `transaction` (
  `transaction_ID` bigint(20) NOT NULL,
  `from_accNo` bigint(20) NOT NULL,
  `to_accNo` bigint(20) NOT NULL,
  `amount` double NOT NULL,
  `Date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `transaction`
--

INSERT INTO `transaction` (`transaction_ID`, `from_accNo`, `to_accNo`, `amount`, `Date`) VALUES
(9621968130, 352283830324, 471600540054, 100.98, '2024-08-22');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `account`
--
ALTER TABLE `account`
  ADD PRIMARY KEY (`accno`);

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `customer`
--
ALTER TABLE `customer`
  ADD PRIMARY KEY (`cid`),
  ADD UNIQUE KEY `aadhar` (`aadhar`);

--
-- Indexes for table `loan`
--
ALTER TABLE `loan`
  ADD PRIMARY KEY (`cid`);

--
-- Indexes for table `registration`
--
ALTER TABLE `registration`
  ADD PRIMARY KEY (`cid`);

--
-- Indexes for table `transaction`
--
ALTER TABLE `transaction`
  ADD PRIMARY KEY (`transaction_ID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `customer`
--
ALTER TABLE `customer`
  MODIFY `cid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=43;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
